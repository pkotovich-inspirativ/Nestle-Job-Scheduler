package routines;

import static com.delvepartners.db.etl.Util.cleanUSPostalCode;
import static com.delvepartners.db.etl.Util.setParameter;
import static com.delvepartners.db.etl.Util.upper;
import static com.delvepartners.db.etl.Util.empty;
import static com.delvepartners.db.etl.Util.cleanEmail;

import com.delvepartners.db.etl.ClientOrderKey;
import com.delvepartners.db.etl.ClientProductKey;
import com.delvepartners.db.etl.CountryCodeLookup;
import com.delvepartners.db.etl.ETLKey;
import com.delvepartners.db.etl.LocationKey;
import com.delvepartners.db.etl.ClientContactKey;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

/*
 * user specification: the function's comment should contain keys as follows:
 *
 * 1. write about the function's comment.but it must be before the "{talendTypes}" key.
 *
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 *
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 *
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 *
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 *
 * 5. {example} gives a example for the Function. it is optional.
 */
public class DataLookups {

    //@todo this may cause a memory leak depending on how much this class may be shared across connections.
    private static Map<ClientOrderKey, Integer> CLIENT_ORDER_KEY_MAP = new HashMap<ClientOrderKey, Integer>();
    private static Map<ClientProductKey, Integer> PRODUCT_SKU_LOOKUP = new HashMap<ClientProductKey, Integer>();
    private static Map<LocationKey, Integer> LOCATION_LOOKUP = new HashMap<LocationKey, Integer>();
    private static Map<ETLKey, Integer> ETLJOB_LOOKUP = new HashMap<ETLKey, Integer>();
    private static Map<ClientContactKey, Integer> CLIENT_CONTACT_KEY_MAP = new HashMap<ClientContactKey, Integer>();

    /**
     * lookupProductOrderId: returns the orderId for an order, or generates a new one if not found.
     *
     * {talendTypes} int | Integer
     *
     * {Category} User Defined
     *
     * {param} java.sql.Connection("conn_tPostgresqlOutput_1") connection: connection being employed in the current transaction.
     *
     * {param} int(1) clientId: the unique ID for this client.
     *
     * {param} string("clientOrderId") clientOrderId : the client's unique ID for the order.
     *
     * {param} string("clientOrderLineId") clientOrderLineId : the client's unique ID for the order line.
     *
     * {example} lookupProductOrderId(1234, "ORDER12345678", "2")
     */
    public static int lookupProductOrderId(Connection connection, int clientId, String clientOrderId, String clientOrderLineId) {
        if(empty(clientOrderId)) {
            throw new IllegalArgumentException("got empty clientOrderId");
        }
        if(empty(clientOrderLineId)) {
            throw new IllegalArgumentException("got empty clientOrderLineId");
        }
        Statement statement = null;
        ResultSet results = null;
        try {
            ClientOrderKey key = new ClientOrderKey(clientId, clientOrderId);
            if(CLIENT_ORDER_KEY_MAP.containsKey(key)){
                return CLIENT_ORDER_KEY_MAP.get(key);
            } else {
                statement = connection.createStatement();
                results = statement.executeQuery("SELECT nextval('delve.product_order_id_seq')");
                Integer orderId = null;
                if(results.next()) {
                    orderId = results.getInt(1);
                }
                if(null == orderId) {
                    throw new IllegalStateException("unable to obtain nextval from sequence!");
                }
                CLIENT_ORDER_KEY_MAP.put(key, orderId);
                return orderId;
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(null != results) {
                    results.close();
                }
                if(null != statement) {
                    statement.close();
                }
            } catch (SQLException ee) {
                //noinspection ThrowFromFinallyBlock
                throw new IllegalStateException(ee);
            }
        }
    }

    /**
     * mergeProduct: returns the productId for a product, or generates a new one if not found.
     *
     * {talendTypes} int | Integer
     *
     * {Category} User Defined
     *
     * {param} java.sql.Connection("conn_tPostgresqlOutput_1") connection: connection being employed in the current transaction.
     * {param} string("clientId") clientId: The Delve client ID
     * {param} string("clientProductSku") clientProductSku: The client's unique ID for the product
     * {param} string("productDescription") productDescription: Optional description
     * {param} string("productVendor") productVendor: Optional vendor description
     * {param} string("productBrand") productBrand: Optional brand description
     * {param} string("productColor") productColor: Optional color description
     * {param} string("productSeries") productSeries: Optional series description
     * {param} string("productShippingWeight") productShippingWeight: Optional weight (numeric)
     * {param} string("productShippingWeightUnits") productShippingWeightUnits: Optional weight units (req'd if weight provided)
     * {param} string("productSize") productSize: Optional size description
     * {param} string("productCategory1") productCategory1: Optional category description
     * {param} string("productCategory2") productCategory2: Optional category description
     * {param} string("productCategory3") productCategory3: Optional category description
     * {param} string("productCategory4") productCategory4: Optional category description
     * {param} string("productCategory5") productCategory5: Optional category description
     * {param} string("productCategory6") productCategory6: Optional category description
     *
     * {example} upsertProduct(conn_tPostgresqlOutput_1, 1234, "SKU12345678", "my product description",...)
     */
    public static int mergeProduct(Connection connection,
                                   int clientId,
                                   String clientProductSku,
                                   String productDescription,
                                   String productVendor,
                                   String productBrand,
                                   String productColor,
                                   String productSeries,
                                   String productShippingWeight,
                                   String productShippingWeightUnits,
                                   String productSize,
                                   String productCategory1,
                                   String productCategory2,
                                   String productCategory3,
                                   String productCategory4,
                                   String productCategory5,
                                   String productCategory6) {

        ClientProductKey key = new ClientProductKey(clientId, clientProductSku);
        if(PRODUCT_SKU_LOOKUP.containsKey(key)) {
            return PRODUCT_SKU_LOOKUP.get(key);
        }

        BigDecimal weight = null;
        if(!empty(productShippingWeight)) {
            weight = new BigDecimal(productShippingWeight);
        }

        CallableStatement statement = null;
        try {
            int i=1;
            statement = connection.prepareCall("{? = call delve.dp_merge_product(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            statement.registerOutParameter(i++, Types.INTEGER);
            setParameter(statement, i++, clientId, Types.INTEGER);
            setParameter(statement, i++, clientProductSku, Types.VARCHAR);
            setParameter(statement, i++, productDescription, Types.VARCHAR);
            setParameter(statement, i++, productVendor, Types.VARCHAR);
            setParameter(statement, i++, productBrand, Types.VARCHAR);
            setParameter(statement, i++, productColor, Types.VARCHAR);
            setParameter(statement, i++, productSeries, Types.VARCHAR);
            setParameter(statement, i++, weight, Types.NUMERIC);
            setParameter(statement, i++, productShippingWeightUnits, Types.VARCHAR);
            setParameter(statement, i++, productSize, Types.VARCHAR);
            setParameter(statement, i++, productCategory1, Types.VARCHAR);
            setParameter(statement, i++, productCategory2, Types.VARCHAR);
            setParameter(statement, i++, productCategory3, Types.VARCHAR);
            setParameter(statement, i++, productCategory4, Types.VARCHAR);
            setParameter(statement, i++, productCategory5, Types.VARCHAR);
            setParameter(statement, i,   productCategory6, Types.VARCHAR);

            statement.execute();

            int productId = statement.getInt(1);
            PRODUCT_SKU_LOOKUP.put(key, productId);

            return productId;
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(null != statement) {
                    statement.close();
                }
            } catch (SQLException ee) {
                //noinspection ThrowFromFinallyBlock
                throw new IllegalStateException(ee);
            }
        }
    }

    /**
     * mergeLocation: returns the locationId for a location, or generates a new one if not found.
     *
     * {talendTypes} int | Integer
     *
     * {Category} User Defined
     *
     * {param} java.sql.Connection("conn_tPostgresqlOutput_1") connection: connection being employed in the current transaction.
     *
     * {param} string("city") city : the city of this location.
     *
     * {param} string("state") state : the state of this location.
     *
     * {param} string("postCode") postCode : the postal code of this location.
     *
     * {param} string("country") country : the two-letter country code of this location.
     *
     * {example} mergeLocation(conn_tPostgresqlOutput_1, "Brooklyn", "NY", "11211", "US")
     *
     */
    public static int mergeLocation(Connection connection, String city, String state, String postCode, String country) {
        if(empty(postCode)) {
            return 0;
        }

        String countryCode = empty(country) ? "US" : country;
        if(!CountryCodeLookup.isValidCode(countryCode)) {
            return 0;
        }

        String postalCode;
        if(countryCode.equals("US")) {
            if (postCode.length() == 4) {
                // assume it's missing a leading 0
                postCode = "0" + postCode;
            }

            if (postCode.length() < 5) {
                return 0;
            }
            postalCode = cleanUSPostalCode(postCode);
        } else {
            postalCode = postCode;
        }

        LocationKey key = new LocationKey(postalCode, countryCode);
        if(LOCATION_LOOKUP.containsKey(key)) {
            return LOCATION_LOOKUP.get(key);
        }
        CallableStatement statement = null;
        try {
            int i=1;
            statement = connection.prepareCall("{? = call delve.dp_merge_location(?,?,?,?)}");
            statement.registerOutParameter(i++, Types.INTEGER);
            setParameter(statement, i++, upper(city), Types.VARCHAR);
            setParameter(statement, i++, upper(state), Types.VARCHAR);
            setParameter(statement, i++, upper(postalCode), Types.VARCHAR);
            setParameter(statement, i, upper(countryCode), Types.VARCHAR);

            statement.execute();

            int locationId = statement.getInt(1);
            LOCATION_LOOKUP.put(key, locationId);

            return locationId;
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(null != statement) {
                    statement.close();
                }
            } catch (SQLException ee) {
                //noinspection ThrowFromFinallyBlock
                throw new IllegalStateException(ee);
            }
        }
    }

    /**
     * mergeETLJob: returns the runId for an ETL job, or generates a new one if not found.
     *
     * {talendTypes} int | Integer
     *
     * {Category} User Defined
     *
     * {param} java.sql.Connection("conn_tPostgresqlOutput_1") connection: connection being employed in the current transaction.
     *
     * {param} string("sourceFilename") sourceFilename : the source file or URL for the ETL job.
     *
     * {param} string("sourceFileMD5") sourceFileMD5 : the MD5 checksum for the source data.
     *
     * {param} string("sourceFilesize") sourceFilesize : the length in bytes of the source data.
     *
     * {param} string("sourceFiledate") sourceFiledate : the unix time of the modify date for the source data.
     *
     * {example} mergeETLJob(conn_tPostgresqlOutput_1, "/path/to/sourcefile", "ASASFQWERQERASDFADF", 123456789, 987654321)
     *
     */

    public static int mergeETLJob(Connection connection, String sourceFilename, String sourceFileMD5, long sourceFilesize, long sourceFiledate) {
        if(empty(sourceFilename) || empty(sourceFileMD5)) {
            throw new IllegalArgumentException("both source filename & md5 are required.");
        }

        ETLKey etlKey = new ETLKey(sourceFilename, sourceFileMD5);
        if(ETLJOB_LOOKUP.containsKey(etlKey)) {
            return ETLJOB_LOOKUP.get(etlKey);
        }

        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
        calendar.setTimeInMillis(sourceFiledate);
        Date sourceFileModifyDate = calendar.getTime();

        String currentUser = System.getProperty("user.name");

        CallableStatement statement = null;
        try {
            int i=1;
            statement = connection.prepareCall("{? = call delve.dp_etl_job_run(?,?,?,?,?)}");
            statement.registerOutParameter(i++, Types.INTEGER);
            setParameter(statement, i++, sourceFilename, Types.VARCHAR);
            setParameter(statement, i++, sourceFileMD5, Types.VARCHAR);
            setParameter(statement, i++, sourceFilesize, Types.INTEGER);
            setParameter(statement, i++, sourceFileModifyDate, Types.TIMESTAMP);
            setParameter(statement, i, currentUser, Types.VARCHAR);

            statement.execute();

            int runId = statement.getInt(1);
            ETLJOB_LOOKUP.put(etlKey, runId);

            return runId;
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(null != statement) {
                    statement.close();
                }
            } catch (SQLException ee) {
                //noinspection ThrowFromFinallyBlock
                throw new IllegalStateException(ee);
            }
        }
    }

    /**
     * mergeContact: returns the contactId for a contact, or generates a new one if not found.
     *
     * {talendTypes} int | Integer
     *
     * {Category} User Defined
     *
     * {param} java.sql.Connection("conn_tPostgresqlOutput_1") connection: connection being employed in the current transaction.
     *
     * {param} string("emailAddress") emailAddress : the email of this contact.
     *
     * {param} string("contactName") contactName : the name of this contact.
     *
     *
     * {example} mergeLocation(conn_tPostgresqlOutput_1, "mrfreeman@yahoo.com", "mr freeman")
     */
    public static int mergeContact(Connection connection, String emailAddress, String contactName) {
        if(empty(emailAddress)) {
            throw new IllegalArgumentException("emailAddress is required.");
        }

        ClientContactKey contactKey = new ClientContactKey(emailAddress);
        if(CLIENT_CONTACT_KEY_MAP.containsKey(contactKey)) {
            return CLIENT_CONTACT_KEY_MAP.get(contactKey) ;
        }

        CallableStatement statement = null;
        try {
            int i=1;
            statement = connection.prepareCall("{? = call delve.dp_merge_contact(?,?)}");
            statement.registerOutParameter(i++, Types.INTEGER);
            setParameter(statement, i++, cleanEmail(emailAddress), Types.VARCHAR);
            setParameter(statement, i++, contactName, Types.VARCHAR);

            statement.execute();

            int contactId = statement.getInt(1);
            CLIENT_CONTACT_KEY_MAP.put(contactKey, contactId);

            return contactId;
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(null != statement) {
                    statement.close();
                }
            } catch (SQLException ee) {
                //noinspection ThrowFromFinallyBlock
                throw new IllegalStateException(ee);
            }
        }

    }
}
